import pandas as pd
import joblib

#  trained model
model = joblib.load("harvest_model.pkl")
scaler = joblib.load("scaler.pkl")

# new data
new_data = pd.DataFrame({
    "Planting Date": [pd.to_datetime("2024-07-01").toordinal()],
    "Growth Stage (Days)": [20],
    "Temperature (°C)": [29],
    "Humidity (%)": [67],
    "Light Exposure (hrs/day)": [11],
    "Soil Moisture (%)": [30],
    "Pesticide Used (Yes=1, No=0)": [1],
})


new_data_scaled = scaler.transform(new_data)

# Predict
predicted_harvest_days = model.predict(new_data_scaled)
print(f"Predicted Harvest Days for new data: {predicted_harvest_days[0]:.0f} days")
