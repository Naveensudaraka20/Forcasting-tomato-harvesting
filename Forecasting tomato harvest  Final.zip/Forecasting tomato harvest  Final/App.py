from flask import Flask, request, render_template
import pandas as pd
import joblib
import datetime
import firebase_admin
from firebase_admin import credentials, db

app = Flask(__name__)

# Load model and scaler
model = joblib.load("harvest_model.pkl")
scaler = joblib.load("scaler.pkl")

# Initialize Firebase Admin SDK
cred = credentials.Certificate("watering-7b4c7-firebase-adminsdk-ntnzb-ee048fb927.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://watering-7b4c7-default-rtdb.firebaseio.com/'
})

# Realtime Database path
sensor_ref = db.reference('/sensors')

# Sensor data
def get_sensor_data():
    ref = db.reference('/sensors')  
    data = ref.get()
    return data
    
@app.route('/', methods=['GET', 'POST'])
def predict():
    prediction = None

    # Get sensor data
    sensor_data = get_sensor_data()

    temperature = humidity = soil_moisture = light_level = None

    if sensor_data:
        temperature = sensor_data.get('temperature', '')
        humidity = sensor_data.get('humidity', '')
        soil_moisture = sensor_data.get('soilMoisture', '')
        light_level = sensor_data.get('lightLevel', '')

    if request.method == 'POST':
        try:
            planting_date = request.form['planting_date']
            growth_stage = int(request.form['growth_stage'])
            temperature = float(request.form['temperature'])
            humidity = float(request.form['humidity'])
            light_exposure = float(request.form['light_exposure'])
            soil_moisture = float(request.form['soil_moisture'])
            pesticide_used = int(request.form['pesticide_used'])

            planting_date_ordinal = datetime.datetime.strptime(planting_date, "%Y-%m-%d").toordinal()

            # Create dataframe
            new_data = pd.DataFrame({
                "Planting Date": [planting_date_ordinal],
                "Growth Stage (Days)": [growth_stage],
                "Temperature (°C)": [temperature],
                "Humidity (%)": [humidity],
                "Light Exposure (hrs/day)": [light_exposure],
                "Soil Moisture (%)": [soil_moisture],
                "Pesticide Used (Yes=1, No=0)": [pesticide_used],
            })

            new_data_scaled = scaler.transform(new_data)
            predicted_harvest_days = model.predict(new_data_scaled)
            prediction = f"Predicted Harvest Days: {predicted_harvest_days[0]:.0f} days"

        except Exception as e:
            prediction = f"Error: {str(e)}"

    # Pass sensor data to template
    return render_template('index.html', prediction=prediction, temperature=temperature, humidity=humidity,
                           soil_moisture=soil_moisture, light_level=light_level)


if __name__ == '__main__':
    app.run(debug=True)
