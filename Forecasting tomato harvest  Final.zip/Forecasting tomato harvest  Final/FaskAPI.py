from flask import Flask, request, jsonify
import pandas as pd
import joblib
app = Flask(__name__)


model = joblib.load("harvest_model.pkl")
scaler = joblib.load("scaler.pkl")


#  API route
@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        new_data = pd.DataFrame({
            "Planting Date": [pd.to_datetime(data['planting_date']).toordinal()],
            "Growth Stage (Days)": [data['growth_stage_days']],
            "Temperature (°C)": [data['temperature']],
            "Humidity (%)": [data['humidity']],
            "Light Exposure (hrs/day)": [data['light_exposure']],
            "Soil Moisture (%)": [data['soil_moisture']],
            "Pesticide Used (Yes=1, No=0)": [data['pesticide_used']],
        })


        new_data_scaled = scaler.transform(new_data)
        predicted_harvest_days = model.predict(new_data_scaled)
        return jsonify({
            'predicted_harvest_days': int(predicted_harvest_days[0])
        })

    except Exception as e:
        return jsonify({'error': str(e)}), 400


if __name__ == '__main__':
    app.run(debug=True)
